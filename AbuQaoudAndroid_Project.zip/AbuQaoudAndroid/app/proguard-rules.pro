# No custom rules are required. WebView and AndroidX dependencies provide their own consumer rules.
